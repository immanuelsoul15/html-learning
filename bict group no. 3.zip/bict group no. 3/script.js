const typingElement = document.querySelector(".typing");

if(typingElement){

const texts = [

"Future IT Professionals",
"Frontend Developers",
"Backend Engineers",
"Cyber Security Experts",
"Tech Innovators"

];

let count = 0;
let index = 0;
let currentText = "";
let letter = "";

(function type(){

if(count === texts.length){
count = 0;
}

currentText = texts[count];

letter = currentText.slice(0, ++index);

typingElement.textContent = letter;

if(letter.length === currentText.length){

count++;

index = 0;

setTimeout(type,1500);

}else{

setTimeout(type,100);

}

})();

}